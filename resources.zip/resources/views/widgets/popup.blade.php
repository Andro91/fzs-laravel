data-toggle="popover" data-placement="{{$direction}}" title="" data-original-title= "{{ $title}}" data-content="{{ $content }}"       
             