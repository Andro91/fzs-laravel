	

<div id="areachart"></div>