@extends('layouts.layout')
@section('section')
    <div class="col-sm-12" style="margin-bottom: 5%">
        <div class="row">
            <div class="col-lg-12 text-center">
                <img src="images/fzs_image.jpg">

                <h1>Факултет за спорт Београд</h1>
            </div>
        </div>
        <hr>
    </div>
@endsection
