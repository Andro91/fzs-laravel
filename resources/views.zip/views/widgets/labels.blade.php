
<span class="label label-{{{ isset($class) ? $class : 'default' }}}">{{$value}}</span>
