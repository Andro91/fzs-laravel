<i class="fa fa-{{$class}}"></i>

