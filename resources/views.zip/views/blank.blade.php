@extends('layouts.layout')
@section('page_heading','Blank')
@section('section')
           
           
            
@stop
